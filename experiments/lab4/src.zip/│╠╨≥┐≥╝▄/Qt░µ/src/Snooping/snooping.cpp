#include"snooping.h"
#include<QDebug>

//***************************Cache***********************************

Cache::Cache()
{
    reset();
}

void Cache::reset()
{
    int i;
    for(i=0;i<CACHE_SIZE;i++)
    {
        _status[i]=I;//Invalid
        _memAddr[i]=-1;
    }
}


//***************************Snooping***********************************

Snooping::Snooping()
{

    _cache.resize(CACHE_NUM);
    clear_status();

}

int Snooping::get_local_wb_addr()
{
    return _local_wb_addr;
}

int Snooping::get_remote_wb_addr()
{
    return _remote_wb_addr;
}

void Snooping::reset()
{
    int i;
    for(i=0;i<_cache.size();i++)
    {
        _cache.at(i).reset();
    }
    clear_status();

}

enum snooping_status *Snooping::get_status()
{


    return _status;
}

void Snooping::read_miss(int cpuIndex,int memAddr)
{

}

void Snooping::write_miss(int cpuIndex,int memAddr)
{

}

void Snooping::invalid(int cpuIndex,int memAddr)
{


}

void Snooping::clear_status()
{
    int i;
    for(i=0;i<5*CACHE_NUM;i++)
    {
        _status[i]=NO_ACTION;
    }
}


void Snooping::read(int cpuIndex,int memAddr)
{

}

void Snooping::write(int cpuIndex,int memAddr)
{

}
