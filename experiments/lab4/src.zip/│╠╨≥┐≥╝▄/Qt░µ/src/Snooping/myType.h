#ifndef MYTYPE_H
#define MYTYPE_H

#include<QString>

#define CACHE_SIZE 4
#define CACHE_NUM 4
#define MEM_SIZE 32



enum MSI{M=0,S,I};
//const QString MSI_Str[3]={"独占","共享","失效"};

enum snooping_status{NO_ACTION,READ_HIT,WRITE_HIT,READ_MISS,
                     WRITE_MISS,INVALID,SHARED,MODIFIED};

const QString status_str[8]={"","读取命中","写命中","读取缺失",
                          "写缺失","失效","共享","独占"};
#endif // MYTYPE_H
