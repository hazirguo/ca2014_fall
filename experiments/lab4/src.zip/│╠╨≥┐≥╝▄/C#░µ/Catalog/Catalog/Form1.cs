﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Catalog
{
    public partial class Form1 : Form
    {

        public struct Cache
        {
            public int addrOfMem, status;
        };
        private Cache[][] cache = new Cache[4][];
        public struct Mem
        {
            public int []list;
            public int status;
        };
        private Mem[][] mem = new Mem[4][];
        private System.Windows.Forms.DataGridView[] dataGridView = new System.Windows.Forms.DataGridView[8];
        private System.Windows.Forms.TextBox[] textBox = new System.Windows.Forms.TextBox[4];
        private System.Windows.Forms.ComboBox[] comboBox = new System.Windows.Forms.ComboBox[4];
        private System.Drawing.Color invalid, shared, modified, unbuffered;
        public Form1()
        {

            InitializeComponent();
            int i, j , k;
            invalid = SystemColors.ActiveBorder;
            shared = System.Drawing.Color.Cyan;
            modified = System.Drawing.Color.Red;
            unbuffered = System.Drawing.Color.Yellow;

            comboBox5.SelectedIndex = 0;
            dataGridView[0] = this.dataGridView1;
            dataGridView[1] = this.dataGridView2;
            dataGridView[2] = this.dataGridView3;
            dataGridView[3] = this.dataGridView4;
            dataGridView[4] = this.dataGridView5;
            dataGridView[5] = this.dataGridView6;
            dataGridView[6] = this.dataGridView7;
            dataGridView[7] = this.dataGridView8;
            textBox[0] = this.textBox1;
            textBox[1] = this.textBox2;
            textBox[2] = this.textBox3;
            textBox[3] = this.textBox4;
            comboBox[0] = this.comboBox1;
            comboBox[1] = this.comboBox2;
            comboBox[2] = this.comboBox3;
            comboBox[3] = this.comboBox4;

            for (i = 0; i < 4; i++)
            {
                // dataGridView[i].AutoResizeRows(DataGridViewAutoSizeRowsMode.AllCells);
                dataGridView[i].AllowUserToAddRows = false;
                dataGridView[i].Rows.Add("0", "");
                dataGridView[i].Rows.Add("1", "");
                dataGridView[i].Rows.Add("2", "");
                dataGridView[i].Rows.Add("3", "");

                dataGridView[i].Rows[0].Cells[1].Style.BackColor = invalid;
                dataGridView[i].Rows[1].Cells[1].Style.BackColor = invalid;
                dataGridView[i].Rows[2].Cells[1].Style.BackColor = invalid;
                dataGridView[i].Rows[3].Cells[1].Style.BackColor = invalid;
            }
            for (i = 4; i < 8; i++)
            {
                dataGridView[i].AllowUserToAddRows = false;
                for (j = 0; j < 8; j++)
                {
                    dataGridView[i].Rows.Add(j.ToString(), "");
                    dataGridView[i].Rows[j].Cells[2].Style.BackColor = unbuffered;
                }
                
            }
            comboBox1.SelectedIndex = 0;
            comboBox2.SelectedIndex = 0;
            comboBox3.SelectedIndex = 0;
            comboBox4.SelectedIndex = 0;
            textBox1.Text = "0";
            textBox2.Text = "0";
            textBox3.Text = "0";
            textBox4.Text = "0";

            for (i = 0; i < 4; i++)
            {
                cache[i] = new Cache[4];
                for (j = 0; j < 4; j++)
                {
                    cache[i][j].addrOfMem = -1;
                    cache[i][j].status = 0;
                }
            }
            for (i = 0; i < 4; i++)
            {
                mem[i] = new Mem[8];
                for (j = 0; j < 8; j++)
                {
                    mem[i][j].status = 0;
                    mem[i][j].list = new int[4];
                    for (k = 0; k < 4; k++)
                    {
                        mem[i][j].list[k] = 0;
                    }
                }
            }
        }

        private void action(int x, int y, int p, int q)
        {
            int j;
            
            for (j = 0; j < 4; j++)
            {
                dataGridView[x].Rows[y].Cells[1].Style.BackColor = System.Drawing.Color.Pink;
                dataGridView[p].Rows[q].Cells[1].Style.BackColor = System.Drawing.Color.Pink;
                dataGridView[x].Rows[y].Cells[1].Value = "   源";
                dataGridView[p].Rows[q].Cells[1].Value = "   目的";
                dataGridView[x].Refresh();
                dataGridView[p].Refresh();
                System.Threading.Thread.Sleep(200);
                dataGridView[x].Rows[y].Cells[1].Style.BackColor = System.Drawing.Color.White;
                dataGridView[p].Rows[q].Cells[1].Style.BackColor = System.Drawing.Color.White;
                dataGridView[x].Rows[y].Cells[1].Value = "   ";
                dataGridView[p].Rows[q].Cells[1].Value = "   ";
                dataGridView[x].Refresh();
                dataGridView[p].Refresh();
                System.Threading.Thread.Sleep(200);
            }
            return;
        }
        private void nullify(int p, int q)
        {
            int j;
            for (j = 0; j < 4; j++)
            {
                dataGridView[p].Rows[q].Cells[1].Style.BackColor = System.Drawing.Color.Pink;
                dataGridView[p].Rows[q].Cells[1].Value = "   失效";
                dataGridView[p].Refresh();
                System.Threading.Thread.Sleep(200);
                dataGridView[p].Rows[q].Cells[1].Style.BackColor = System.Drawing.Color.White;
                dataGridView[p].Rows[q].Cells[1].Value = "   ";
                dataGridView[p].Refresh();
                System.Threading.Thread.Sleep(200);
            }
            return;
        }
        private int calc(int i, int addr, int connect)
        {
            int addrOfCache, p, j;
            Random ran = new Random();
            switch (connect)
            {
                case 1:
                    addrOfCache = addr % 4;
                    break;
                case 2:
                    p = addr % 2;

                    for (j = p + p; j <= p + p + 1; j++)
                    {
                        if (cache[i][j].addrOfMem == addr)
                            return j;
                    }
                    for (j = p + p; j <= p + p + 1; j++)
                    {
                        if (cache[i][j].status == 0)
                            return j;
                    }
                    j = ran.Next(2);
                    addrOfCache = p + p + j;
                    break;
                case 4:
                    p = addr % 1;
                    for (j = 0; j <= 3; j++)
                    {
                        if (cache[i][j].addrOfMem == addr)
                            return j;
                    }
                    for (j = 0; j <= 3; j++)
                    {
                        if (cache[i][j].status == 0)
                            return j;
                    }
                    j = ran.Next(4);
                    addrOfCache = j;
                    break;
                default:
                    addrOfCache = 0;
                    break;
            }
            return addrOfCache;

        }
        private void Simulate(int i)
        {
            // 填写模拟实现函数
        }

       

        private void button_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Simulate(0);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Simulate(1);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Simulate(2);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Simulate(3);
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
